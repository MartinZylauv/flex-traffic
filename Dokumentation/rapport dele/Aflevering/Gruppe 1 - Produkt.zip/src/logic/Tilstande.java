package logic;

public enum Tilstande {

	BEREGNER, BEREGNET, NULSTILLET,VALIDERINGSFEJL,BEREGNINGSFEJL;
}
