
public class Biludlejningssystem {
	
	private Bilklasse[] bilklasse;
	private Reservation[] reservationer;
	
	public Bilklasse[] getBilklasser() {
		return null;
	}
	
	public Reservation[] getReservationer() {
		return reservationer;
	}

}
