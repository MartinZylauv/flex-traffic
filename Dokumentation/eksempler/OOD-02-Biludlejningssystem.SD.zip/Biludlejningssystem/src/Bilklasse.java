
public class Bilklasse {
	
	private int pris;
	private String betegnelse;
	private int antal;
	
	public int getPris() {
		// TODO Implementeres senere
		return 0;
	}
	
	public String getBetegnelse() {
		// TODO Ej implementeret
		return null;
	}
	
	public int getAntal() {
		return antal;
	}

}
