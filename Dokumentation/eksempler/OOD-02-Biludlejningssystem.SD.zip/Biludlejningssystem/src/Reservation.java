import java.time.LocalDate;


public class Reservation {
	
	private LocalDate udlTid;
	private LocalDate aflTid;
	
	public LocalDate getUdlTid() {
		return udlTid;
	}
	
	public LocalDate getAflTid() {
		return aflTid;
	}

}
