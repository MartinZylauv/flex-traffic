import java.time.LocalDate;


public class ReservationsController {
	
	private Biludlejningssystem bus;
	
	public Bilklasse[] visBilklasser() {
		return null;
	}
	
	public boolean kontrollerLedighed(Bilklasse bilklasse, 
			LocalDate starttid, LocalDate sluttid) {
		Reservation[] reservationer = bus.getReservationer();
		
		int antal = bilklasse.getAntal();
		
		for (int i = 0; i < reservationer.length; i++) {
			LocalDate udlTid = reservationer[i].getUdlTid();
			LocalDate aflTid = reservationer[i].getAflTid();
			
			if ((starttid.isAfter(udlTid) & starttid.isBefore(aflTid))
					|(sluttid.isAfter(udlTid) & sluttid.isBefore(aflTid))
					|(starttid.isBefore(udlTid) & sluttid.isAfter(aflTid))) {
				antal--;
			}
			
		}
		
		return antal > 0;
	}
}
